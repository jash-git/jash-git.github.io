To run the demo you need to include some js and css files.
You can download it from http://jquery-easyui.wikidot.com/download.


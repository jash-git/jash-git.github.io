<?php

$name = $_POST['name'];
$address = $_POST['address'];
$city = $_POST['city'];

echo "Your Name: $name <br/> Your Address: $address <br/> Your City ID: $city";

?>